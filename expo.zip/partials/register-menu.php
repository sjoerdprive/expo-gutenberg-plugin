<?php
register_nav_menu('expo_menu', 'Exposities');
